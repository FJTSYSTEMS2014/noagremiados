<?php
header("Content-Type: application/json");

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $request = json_decode(file_get_contents("php://input"), true);

    if (isset($request["candidato"]) && isset($request["codigo"])) {
        $candidato = $request["candidato"];
        $codigo = $request["codigo"];
        $codigos = json_decode(file_get_contents("../js_/codigos.json"), true);

        if (array_key_exists($codigo, $codigos) && !$codigos[$codigo]) {
            $codigos[$codigo] = true;

            // Registrar el voto en resultados.json
            $resultados = json_decode(file_get_contents("../js_/resultados.json"), true);
            $resultados[$candidato][] = $codigo;

            file_put_contents("../js_/codigos.json", json_encode($codigos));
            file_put_contents("../js_/resultados.json", json_encode($resultados));

            echo json_encode(["success" => true]);
        } else {
            echo json_encode(["success" => false]);
        }
    } else {
        echo json_encode(["success" => false]);
    }
} else {
    echo json_encode(["success" => false]);
}
?>
