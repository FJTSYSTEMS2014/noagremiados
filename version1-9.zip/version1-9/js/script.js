document.addEventListener("DOMContentLoaded", function () {
    // Cargar candidatos desde postulantes.json
    fetch("js_/postulantes.json")
        .then(response => response.json())
        .then(data => {
            const candidatosContainer = document.getElementById("candidatos");
            data.forEach(candidato => {
                const candidatoDiv = document.createElement("div");
                candidatoDiv.innerHTML = `
                    <img src="${candidato.foto}" alt="${candidato.nombre}">
                    <p>${candidato.nombre}</p>
                    <p>${candidato.comentario}</p>
                `;
                candidatosContainer.appendChild(candidatoDiv);
            });
        });

    // Manejar la votación
    const votarForm = document.getElementById("votarForm");
    const mensaje = document.getElementById("mensaje");
    votarForm.addEventListener("submit", function (e) {
        e.preventDefault();
        const candidatoSelect = document.getElementById("candidatoSelect");
        const codigo = document.getElementById("codigo").value;

        if (candidatoSelect.value === "") {
            mensaje.textContent = "Selecciona un candidato antes de votar.";
            return;
        }

        fetch("php/vote.php", {
            method: "POST",
            body: JSON.stringify({ candidato: candidatoSelect.value, codigo }),
        })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    mensaje.textContent = "¡Votación exitosa!";
                } else {
                    mensaje.textContent = "Código inválido. No se pudo votar.";
                }
            });
    });
});

        function abrirURL() {
            window.open('/resultados.html', '_blank');location.reload();
        }
